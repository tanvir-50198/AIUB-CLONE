import myproject.*;
import javax.swing.*;
import java.awt.*;
public class Start {

    public static void main(String[] args) {

         AiubHome ah = new AiubHome();
        ah.setVisible(true);
    }
} 
